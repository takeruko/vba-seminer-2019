# Excelマクロで学ぶVBA入門 第4回 コンテンツ
## フォルダ構成
### last_homework
前回の宿題解答例
 - EvalLeapYear_sample.xlsm
   - 宿題1:閏年の判定マクロ
 - SplitName.xlsm
   - 宿題2: 名前を姓/ミドルネーム/名に分割するマクロ

### exercise
例題「複数の立替経費清算書を一覧表にまとめるツール」で使用するデータ、サンプルフォーマット
  - Expense_Claim_List.xlsm
    - 一覧表＆マクロ用ファイル
  - Expense_Claims_Mar2019.xlsx
    - 立替経費精算表ファイル
